package API_GETWAY.API_GETWAY;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGetwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
